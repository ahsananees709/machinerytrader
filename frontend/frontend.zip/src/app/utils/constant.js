const BASE_URL = 'https://311a-59-103-102-130.ngrok-free.app/api/api'

export {
    BASE_URL
}