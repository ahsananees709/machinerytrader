ALTER TABLE "vehicles" DROP COLUMN "location";--> statement-breakpoint
ALTER TABLE "vehicles" DROP COLUMN "state";